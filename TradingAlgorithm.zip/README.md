
# Trading Algorithm

This repository contains a trading algorithm for financial market analysis and pattern detection. It includes Python scripts for OCR and screen recording, a NinjaTrader strategy in C#, and supporting configuration and data files.

## Repository Structure

```
TradingAlgorithm/
├── Python_Scripts/
│   ├── 1.py                    # General utility script
│   ├── Screen_rec_final.py     # Screen recording and analysis script
│   ├── ORDER_SCAN_FOOTPRINT_ES.py # Footprint order scanning
├── NinjaTrader/
│   └── OCRPLUS.cs              # NinjaTrader strategy implementation
├── Config/
│   └── config.json             # Configuration settings
├── Data/
│   └── candle_data.xlsx        # Sample market data
├── README.md                   # Project documentation
└── requirements.txt            # Python dependencies
```

## Features

- **Order Scanning**: Analyzes market data for specific patterns and divergences.
- **NinjaTrader Integration**: Custom strategy for trading automation.
- **Screen Recording**: Captures live trading screens for analysis.
- **Data Analysis**: Processes and visualizes market data.

## Setup

### Prerequisites

1. Install Python 3.8 or higher.
2. Install required Python libraries:
   ```bash
   pip install -r requirements.txt
   ```
3. Ensure Tesseract-OCR is installed and configured correctly.

### Usage

1. **Order Scanning**:
   - Run `ORDER_SCAN_FOOTPRINT_ES.py` in the `Python_Scripts` folder.

2. **Screen Recording**:
   - Execute `Screen_rec_final.py` for capturing live trading data.

3. **NinjaTrader Strategy**:
   - Import `OCRPLUS.cs` into NinjaTrader as a custom strategy.

## License

This project is licensed under the MIT License. See the LICENSE file for details.

## Contributing

Feel free to fork this repository and submit pull requests.

---

### Contact

For questions or support, please contact [Your Name/Email].
