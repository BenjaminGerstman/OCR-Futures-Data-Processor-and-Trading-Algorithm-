import cv2
import os
import re
from datetime import datetime
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import pytesseract
from collections import defaultdict, deque
import matplotlib.pyplot as plt

# Configuration for Tesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Initialize a history of seen number arrays to avoid repeats
history_length = 650000
column_history = defaultdict(lambda: deque(maxlen=history_length))

# Define color ranges
green_range = (np.array([88 - 10, 70, 50]), np.array([88 + 10, 255, 255]))
red_range1 = (np.array([0, 70, 50]), np.array([10, 255, 255]))
red_range2 = (np.array([170, 70, 50]), np.array([180, 255, 255]))

def preprocess_frame(frame):
    hsv_image = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_green, upper_green = np.array([40, 50, 50]), np.array([80, 255, 255])
    green_mask = cv2.inRange(hsv_image, lower_green, upper_green)
    green_result = cv2.bitwise_and(frame, frame, mask=green_mask)
    return green_result

def extract_column_with_three_lines(frame, padding=0, offset=13):
    total_width = frame.shape[1] - offset
    x_start = int(total_width * 0.09)
    x_end = int(total_width * 0.19)
    start = x_start + padding
    end = x_end - padding
    end = min(end, x_end)
    midpoint_division = (start + end) // 2
    stop_height = int(0.9 * frame.shape[0])

    # Draw the three vertical lines: start, midpoint, and end
    frame[:stop_height, start-1:start+1] = 255
    frame[:stop_height, midpoint_division-1:midpoint_division+1] = 255
    frame[:stop_height, end-1:end+1] = 255
    
    # Extract the columns based on the identified positions
    column = frame[:, start:end]
    columns = [column]  # Example for a single column extraction

    # Add information for bounding boxes if needed
    columns_with_boxes = [{'column': column, 'box': (start, 0, end - start, frame.shape[0]), 'midpoint_division': midpoint_division}]

    return columns, columns_with_boxes

def filter_valid_numbers(text, is_green=True):
    valid_numbers = []
    if is_green:
        pattern = r'\b([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?\b'
        matches = re.findall(pattern, text)
        if matches:
            matches.sort(key=lambda x: x[1])
            hours, minutes, seconds = matches[-1]
            time_str = f"{hours}:{minutes}:{seconds if seconds else '00'}"
            valid_numbers.append(time_str)
    else:
        num_pattern = r'-?\b\d{1,3}\b'
        num_matches = re.findall(num_pattern, text)
        valid_numbers.extend([int(num) for num in num_matches if -999 <= int(num) <= 999])
    return valid_numbers

def calculate_time_difference(time_string1, time_string2):
    def extract_time_components(time_string):
        times = re.findall(r'\b([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?\b', time_string)
        if times:
            hours, minutes, seconds = times[0]
            return int(hours), int(minutes), int(seconds) if seconds else 0
        return 0, 0, 0

    hours1, minutes1, seconds1 = extract_time_components(time_string1)
    hours2, minutes2, seconds2 = extract_time_components(time_string2)
    try:
        start_time = datetime.strptime(f"{hours1}:{minutes1}:{seconds1}", '%H:%M:%S')
        end_time = datetime.strptime(f"{hours2}:{minutes2}:{seconds2}", '%H:%M:%S')
        return abs((end_time - start_time).total_seconds() / 60)
    except ValueError:
        return 0

def find_dominant_color(column, green_range, red_range1, red_range2, ignore_black=True):
    midpoint = column.shape[1] // 2
    left_half = column[:, :midpoint]
    right_half = column[:, midpoint:]
    hsv_left = cv2.cvtColor(left_half, cv2.COLOR_BGR2HSV)
    hsv_right = cv2.cvtColor(right_half, cv2.COLOR_BGR2HSV)
    green_mask_left = cv2.inRange(hsv_left, green_range[0], green_range[1])
    green_mask_right = cv2.inRange(hsv_right, green_range[0], green_range[1])
    red_mask_left = cv2.bitwise_or(cv2.inRange(hsv_left, red_range1[0], red_range1[1]),
                                   cv2.inRange(hsv_left, red_range2[0], red_range2[1]))
    red_mask_right = cv2.bitwise_or(cv2.inRange(hsv_right, red_range1[0], red_range1[1]),
                                    cv2.inRange(hsv_right, red_range2[0], red_range2[1]))
    if ignore_black:
        black_threshold = 50
        threshold_mask_left = (hsv_left[:, :, 2] > black_threshold).astype('uint8') * 255
        threshold_mask_right = (hsv_right[:, :, 2] > black_threshold).astype('uint8') * 255
        green_mask_left = cv2.bitwise_and(green_mask_left, green_mask_left, mask=threshold_mask_left)
        green_mask_right = cv2.bitwise_and(green_mask_right, green_mask_right, mask=threshold_mask_right)
        red_mask_left = cv2.bitwise_and(red_mask_left, red_mask_left, mask=threshold_mask_left)
        red_mask_right = cv2.bitwise_and(red_mask_right, red_mask_right, mask=threshold_mask_right)

    total_red_pixels = np.sum(red_mask_left) + np.sum(red_mask_right)
    dominant_color = 'Buying' if total_red_pixels < 140000 else 'Selling'
    return dominant_color

def prepare_data(video_path, green_range, red_range1, red_range2):
    all_features = []
    all_labels = []
    cap = cv2.VideoCapture(video_path)
    frame_count = 1
    order_flow_number = 1
    last_green_text = None
    skip_frames = 8

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        if frame_count < 1080:
            frame_count += 1
            continue

        columns, columns_with_boxes = extract_column_with_three_lines(frame, padding=2)

        for idx, column_data in enumerate(columns_with_boxes, start=1):
            column = column_data['column']
            bottom_red_line = int(0.96 * column.shape[0])
            ocr_below_red_line = pytesseract.image_to_string(column[bottom_red_line:, :], config='--psm 6').strip()
            valid_times = filter_valid_numbers(ocr_below_red_line, is_green=True)
            if not valid_times:
                continue
            left_bid_text = pytesseract.image_to_string(column[:bottom_red_line, :column.shape[1]//2], config='--psm 6').strip()
            left_bid_numbers = filter_valid_numbers(left_bid_text, is_green=False)
            right_ask_text = pytesseract.image_to_string(column[:bottom_red_line, column.shape[1]//2:], config='--psm 6').strip()
            right_ask_numbers = filter_valid_numbers(right_ask_text, is_green=False)

            delta = sum(right_ask_numbers) - sum(left_bid_numbers)
            if last_green_text:
                time_diff = calculate_time_difference(last_green_text, ocr_below_red_line)
                last_green_text = ocr_below_red_line
            else:
                last_green_text = ocr_below_red_line

            dominant_color = find_dominant_color(column, green_range, red_range1, red_range2)
            feature_vector = [time_diff, len(left_bid_numbers), len(right_ask_numbers), order_flow_number]
            label = 1 if dominant_color == "Buying" else 0
            all_features.append(feature_vector)
            all_labels.append(label)
            order_flow_number += 1

        cv2.imshow('Frame with Columns', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        frame_count += 1
        if frame_count % skip_frames == 0:
            continue

    cap.release()
    cv2.destroyAllWindows()
    return np.array(all_features), np.array(all_labels)

def build_model(input_shape):
    model = Sequential([
        Dense(128, activation='relu', input_shape=(input_shape,)),
        Dropout(0.5),
        Dense(64, activation='relu'),
        Dropout(0.5),
        Dense(2, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    y_pred_classes = np.argmax(y_pred, axis=1)
    accuracy = accuracy_score(y_test, y_pred_classes)
    precision = precision_score(y_test, y_pred_classes, average='weighted')
    recall = recall_score(y_test, y_pred_classes, average='weighted')
    f1 = f1_score(y_test, y_pred_classes, average='weighted')
    auc = roc_auc_score(y_test, y_pred[:, 1], average='weighted', multi_class='ovo')
    return accuracy, precision, recall, f1, auc

def main(video_path):
    save_model_path = r'C:\Users\bgerstman11\Downloads\Delta Divigence ML ScreenRecording Project\path_to_save_your_model'
    if not os.path.exists(video_path):
        print("The video file does not exist.")
        return

    green_range = (np.array([88 - 10, 70, 50]), np.array([88 + 10, 255, 255]))
    red_range1 = (np.array([0, 70, 50]), np.array([10, 255, 255]))
    red_range2 = (np.array([170, 70, 50]), np.array([180, 255, 255]))
    features, labels = prepare_data(video_path, green_range, red_range1, red_range2)

    input_shape = features.shape[1]
    model = build_model(input_shape)
    model.summary()

    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)
    history = model.fit(X_train, y_train, epochs=10, validation_split=0.2)
    model.save(os.path.join(save_model_path, 'trained_model.keras'))

    accuracy, precision, recall, f1, auc = evaluate_model(model, X_test, y_test)
    print("Accuracy:", accuracy)
    print("Precision:", precision)
    print("Recall:", recall)
    print("F1 Score:", f1)
    print("AUC:", auc)

    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.plot(history.history['accuracy'], label='Training Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.title('Training and Validation Accuracy')
    plt.legend()
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    video_file_path = r'C:\Users\bgers\OneDrive\\Delta Divigence ML ScreenRecording Project\Video_Data\October .mp4'
    main(video_file_path)
