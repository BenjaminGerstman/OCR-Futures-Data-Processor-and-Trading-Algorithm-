import numpy as np
import pytesseract
from collections import defaultdict, deque
from datetime import datetime, timedelta
import pytz
import socket
import re
import pyautogui
import threading
import tkinter as tk
from tkinter import ttk
import cv2
import time
import json
import os
import csv
from cryptography.fernet import Fernet
import hashlib
import requests
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Configuration for Tesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Initialize a history of seen number arrays to avoid repeats
history_length = 650000  # Size of history for each column to avoid repeating arrays
column_history = defaultdict(lambda: deque(maxlen=history_length))
recording = False
pattern_mode = "both"  # Default to both buying and selling patterns
client = None
stream = None

green_range = (np.array([88 - 10, 70, 50]), np.array([88 + 10, 255, 255]))  # +/- 10 for hue range
red_range1 = (np.array([0, 70, 50]), np.array([10, 255, 255]))
red_range2 = (np.array([170, 70, 50]), np.array([180, 255, 255]))

# Exclude the borders of the column by a set number of pixels
column_padding = 2
NUM_COLUMNS = 2

# Encryption key (replace with your generated key)
ENCRYPTION_KEY = b'w9Nyb6q2bWwhcnrHzg5G_7blmYfGZgQ6zCeRkYehXys='

import cv2
import numpy as np
import pyautogui
import time

# Function to extract columns and draw lines
import cv2
import numpy as np
import pyautogui
import time

# Function to extract one column and draw three vertical lines: start, midpoint, and end
def extract_column_with_three_lines(frame, padding=0, offset=13):
    total_width = frame.shape[1] - offset  # Adjust total width if there is an offset
    
    # Define start and end positions for the column extraction
    x_start = int(total_width * 0.09)  # Start at 3% of the frame width
    x_end = int(total_width * 0.19)    # End at 15% of the frame width

    # Calculate the starting and ending x position of the column considering the padding
    start = x_start + padding
    end = x_end - padding

    # Ensure the end position does not exceed the specified range
    end = min(end, x_end)

    # Calculate the midpoint division within the column
    midpoint_division = (start + end) // 2
    
    # Calculate the height for the lines to stop vertically at the 20 percent mark
    stop_height = int(0.9 * frame.shape[0])

    # Draw the three vertical lines: start, midpoint, and end
    frame[:stop_height, start-1:start+1] = 255  # Start line
    frame[:stop_height, midpoint_division-1:midpoint_division+1] = 255  # Midpoint line
    frame[:stop_height, end-1:end+1] = 255  # End line
    
    # Calculate the position for the red line to split the column near the bottom
    red_line_position = int(0.93 * frame.shape[0])
    
    # Add the red horizontal line at the bottom of the column
    frame[red_line_position-1:red_line_position+1, start:end] = [0, 0, 255]  # Red line for the column

    return frame


def calculate_time_difference(time_string1, time_string2):
    def extract_time_components(time_string):
        times = re.findall(r'\b([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?\b', time_string)
        if times:
            hours, minutes, seconds = times[0]
            return int(hours), int(minutes), int(seconds) if seconds else 0
        return 0, 0, 0

    hours1, minutes1, seconds1 = extract_time_components(time_string1)
    hours2, minutes2, seconds2 = extract_time_components(time_string2)

    if hours1 == hours2:
        total_seconds1 = hours1 * 3600 + minutes1 * 60 + seconds1
        total_seconds2 = hours2 * 3600 + minutes2 * 60 + seconds2
        time_diff_seconds = abs(total_seconds2 - total_seconds1)
        if time_diff_seconds < 60:
            return time_diff_seconds / 60

    start_time_str = f"{hours1:02d}:{minutes1:02d}:{seconds1:02d}"
    end_time_str = f"{hours2:02d}:{minutes2:02d}:{seconds2:02d}"
    print("Start time:", start_time_str)
    print("End time:", end_time_str)
    try:
        start_time = datetime.strptime(start_time_str, '%H:%M:%S')
        end_time = datetime.strptime(end_time_str, '%H:%M:%S')

        return abs((end_time - start_time).total_seconds() / 60)
    except ValueError:
        print(f"Error parsing times: '{time_string1}' or '{time_string2}'")
    return 0

def find_dominant_color(column, green_range, red_range1, red_range2, ignore_black=True):
    midpoint = column.shape[1] // 2
    left_half = column[:, :midpoint]
    right_half = column[:, midpoint:]

    hsv_left = cv2.cvtColor(left_half, cv2.COLOR_BGR2HSV)
    hsv_right = cv2.cvtColor(right_half, cv2.COLOR_BGR2HSV)

    green_mask_left = cv2.inRange(hsv_left, green_range[0], green_range[1])
    green_mask_right = cv2.inRange(hsv_right, green_range[0], green_range[1])
    red_mask_left = cv2.bitwise_or(cv2.inRange(hsv_left, red_range1[0], red_range1[1]),
                                   cv2.inRange(hsv_left , red_range2[0], red_range2[1]))
    red_mask_right = cv2.bitwise_or(cv2.inRange(hsv_right, red_range1[0], red_range1[1]),
                                    cv2.inRange(hsv_right, red_range2[0], red_range2[1]))

    if ignore_black:
        black_threshold = 50
        threshold_mask_left = (hsv_left[:, :, 2] > black_threshold).astype('uint8') * 255
        threshold_mask_right = (hsv_right[:, :, 2] > black_threshold).astype('uint8') * 255
        green_mask_left = cv2.bitwise_and(green_mask_left, green_mask_left, mask=threshold_mask_left)
        green_mask_right = cv2.bitwise_and(green_mask_right, green_mask_right, mask=threshold_mask_right)
        red_mask_left = cv2.bitwise_and(red_mask_left, red_mask_left, mask=threshold_mask_left)
        red_mask_right = cv2.bitwise_and(red_mask_right, red_mask_right, mask=threshold_mask_right)

    red_pixels_left = np.sum(red_mask_left)
    red_pixels_right = np.sum(red_mask_right)
    total_red_pixels = red_pixels_left + red_pixels_right

    dominant_color = 'Buying' if total_red_pixels < 140000 else 'Selling'

    return dominant_color

def contains_four_consecutive_repeats(numbers):
    for i in range(len(numbers) - 3):
        if numbers[i] == numbers[i + 1] == numbers[i + 2] == numbers[i + 3]:
            return True
    return False

def update_treeview(tree, data):
    # Clear the Treeview
    for item in tree.get_children():
        tree.delete(item)

    # Add new data
    for index, entry in enumerate(data, start=1):
        # Filter out the sequence [30, 1] from bid and ask numbers
        filtered_bid_numbers = [num for num in entry['bid_numbers'] if num not in [30, 1]]
        filtered_ask_numbers = [num for num in entry['ask_numbers'] if num not in [30, 1]]

        # Insert the filtered data into the TreeView
        tree.insert('', 'end', values=(
            index, 

            entry['time'], 
            ','.join(map(str, filtered_bid_numbers)),  # Display filtered bid numbers
            ','.join(map(str, filtered_ask_numbers)),  # Display filtered ask numbers
            entry['dominant_color'], 
            entry['delta'], 
            ','.join(map(str, entry['patterns'])),
            entry['delta_divergence'], 
            entry['volatility_category'], 
            entry['session']
        ))

def determine_divergence(delta, candle_type):
    if candle_type == 'Buying' and delta < 0:  # Selling delta on a buying candle
        return abs(delta)
    elif candle_type == 'Selling' and delta > 0:  # Buying delta on a selling candle
        return abs(delta)
    else:
        return 0

def get_volatility_category(time_difference):
    if time_difference >= 901:
        return 'Very Low Volatility'
    elif 301 <= time_difference <= 900:
        return 'Low Volatility'
    elif 181 <= time_difference <= 300:
        return 'Moderate Volatility'
    elif 61 <= time_difference <= 180:
        return 'High Volatility'
    else:
        return 'Very High Volatility'

def get_session(time_str):
    try:
        hour = datetime.strptime(time_str, '%H:%M:%S').time().hour
    except Exception as e:
        return 'Invalid Time'
    
    if 3 <= hour < 8:
        return '3am - 7:59am'
    elif 8 <= hour < 12:
        return '8am - 11:59am'
    elif 12 <= hour < 14:
        return '12pm - 1:59pm'
    elif 14 <= hour < 16:
        return '2pm - 3:59pm'
    elif 16 <= hour < 18:
        return '4pm - 5:59pm'
    elif 18 <= hour < 21:
        return '6pm - 8:59pm'
    else:
        return '9pm - 2:59am'

def filter_valid_numbers(text, is_green=True):
    valid_numbers = []
    if is_green:
        pattern = r'\b([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?\b'
        matches = re.findall(pattern, text)
        if matches:
            matches.sort(key=lambda x: x[1])
            hours, minutes, seconds = matches[-1]
            time_str = f"{hours}:{minutes}:{seconds if seconds else '00'}"
            valid_numbers.append(time_str)
            
        date_pattern = r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\b'
        date_matches = re.findall(date_pattern, text)
        
        valid_numbers.extend(date_matches)
        
    else:
        num_pattern = r'-?\b\d{1,3}\b'
        num_matches = re.findall(num_pattern, text)
        
        for num in num_matches:
            try:
                num = int(num)
                if -999 <= num <= 999:
                    valid_numbers.append(num)
            except ValueError:
                continue
                
    return valid_numbers

# Global variables
all_data = []

def live_feed_processing(tree):
    global recording, pattern_mode, all_data
    all_data = []
    column_history = defaultdict(lambda: deque(maxlen=history_length))  # Initialize history for each column

    frame_count = 1  # Initialize frame count
    order_flow_number = 1  # Initialize order flow number
    skip_frames = 8  # Frames to skip
    frames_to_skip = 0  # Initialize frames to skip
    last_green_text = None  # Initialize last green text

    previous_bids = []
    previous_asks = []
    previous_delta = None  # Initialize the previous delta

    dominant_colors = deque(maxlen=15)
    deltas = deque(maxlen=15)
    delta_divergences = deque(maxlen=15)
    volatility_categories = deque(maxlen=15)
    deltas3T = deque(maxlen=15)
    deltas5T = deque(maxlen=15)

    target_time = None  # Time to start analyzing columns
    last_pattern_time = None  # Initialize the last pattern detection time

    while recording:
        # Capture the screen using pyautogui
        frame = np.array(pyautogui.screenshot())
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

        # Skip frames if frames_to_skip is not 0
        if frames_to_skip > 0:
            frames_to_skip -= 1
            continue

        # Start processing from frame 300
        if frame_count < 300:
            frame_count += 1
            continue

        # Use the function to extract the column and draw three lines (start, mid, end)
        updated_frame = extract_column_with_three_lines(frame)

        # Display the updated frame in a window (you can remove this for production use)
        cv2.imshow('Screen with Column and Three Lines', updated_frame)

        # Extract data from the column as in the original code
        total_width = frame.shape[1]
        x_start1 = int(total_width * 0.09)  # Adjust start and end positions as needed
        x_end1 = int(total_width * 0.19)    

        column1 = frame[:, x_start1:x_end1]
        midpoint_division1 = column1.shape[1] // 2

        # OCR and pattern detection logic remains the same
        bottom_red_line = int(0.93 * column1.shape[0])
        ocr_below_red_line = pytesseract.image_to_string(column1[bottom_red_line:, :], config='--psm 6').strip()
        valid_times = filter_valid_numbers(ocr_below_red_line, is_green=True)
        
        # Ensure that there is at least one valid time entry, otherwise skip
        if not valid_times:
            print(f"Skipping entry due to missing valid time.")
            continue

        print(f"OCR below red line in Column 0: {valid_times}")

        left_bid_text = pytesseract.image_to_string(column1[:bottom_red_line, :midpoint_division1], config='--psm 6').strip()
        left_bid_numbers = filter_valid_numbers(left_bid_text, is_green=False)
        print(f"Left bid numbers: {left_bid_numbers}")

        right_ask_text = pytesseract.image_to_string(column1[:bottom_red_line, midpoint_division1:], config='--psm 6').strip()
        right_ask_numbers = filter_valid_numbers(right_ask_text, is_green=False)
        print(f"Right ask numbers: {right_ask_numbers}")

        # Ensure bid and ask numbers are between 2 and 12 (instead of 8)
        if len(left_bid_numbers) < 2 or len(right_ask_numbers) < 2:
            print(f"Skipping due to insufficient numbers in bids or asks.")
            continue

        left_bid_numbers = left_bid_numbers[:12]  # Update limit to 12
        right_ask_numbers = right_ask_numbers[:12]  # Update limit to 12

        delta = sum(map(int, right_ask_numbers)) - sum(map(int, left_bid_numbers))

        # Filter out entries if the delta is the same as the previous delta
        if previous_delta is not None and delta == previous_delta:
            print(f"Skipping due to delta being the same as the previous delta.")
            continue

      # Filter out if the first two bid or ask numbers of the next data entry are the same as those of the previous entry
# EXCEPT if the sequence is [30, 1]
        if previous_bids and previous_asks:
            if (left_bid_numbers[:2] == previous_bids[-1][:2] and left_bid_numbers[:2] != [30, 1]) or \
            (right_ask_numbers[:2] == previous_asks[-1][:2] and right_ask_numbers[:2] != [30, 1]):
                print(f"Skipping due to the first two bid or ask numbers being the same as the previous entry, except [30, 1].")
                continue


        # Filter out if the first three bid numbers are the same as those of the previous entry
        if previous_bids:
            common_numbers = set(left_bid_numbers[:3]).intersection(set(previous_bids[-1][:3]))
            if len(common_numbers) >= 3:
                print(f"Skipping due to the same three bid numbers in the previous entry.")
                continue

        start_time, end_time, time_diff = '', '', 0
        if last_green_text is not None:
            time_diff = calculate_time_difference(last_green_text, ocr_below_red_line)
            last_green_text = ocr_below_red_line
        else:
            last_green_text = ocr_below_red_line

        dominant_color = find_dominant_color(column1, green_range, red_range1, red_range2, ignore_black=True)
        delta_divergence = determine_divergence(delta, dominant_color)
        volatility_category = get_volatility_category(time_diff)
        session = get_session(valid_times[0] if valid_times else '')

        previous_delta = delta  # Update the previous delta

        # Check for filtering conditions
        feature_vector = [time_diff, len(left_bid_numbers), len(right_ask_numbers), order_flow_number]
        label = 1 if dominant_color == "Buying" else 0
        all_data.append({
            'time': valid_times[0] if valid_times else '',
            'bid_numbers': left_bid_numbers,
            'ask_numbers': right_ask_numbers,
            'dominant_color': dominant_color,
            'delta': delta,
            'patterns': [],
            'feature_vector': feature_vector,
            'label': label,
            'delta_divergence': delta_divergence,
            'volatility_category': volatility_category,
            'session': session
        })

        column_history[0].append(left_bid_numbers)

        previous_bids.append(left_bid_numbers)
        previous_asks.append(right_ask_numbers)

        order_flow_number += 1
        dominant_colors.append(dominant_color)
        deltas.append(delta)
        delta_divergences.append(delta_divergence)
        volatility_categories.append(volatility_category)

        # **New Code: Detect patterns and send them to NinjaTrader**
        patterns, last_pattern_time = detect_patterns(dominant_colors, deltas, delta_divergences, volatility_categories, deltas3T, deltas5T, left_bid_numbers, right_ask_numbers, last_pattern_time)

        if patterns:
            if pattern_mode == "buy" and dominant_color == "Buying":
                send_patterns_to_ninjatrader(patterns, dominant_color)
            elif pattern_mode == "sell" and dominant_color == "Selling":
                send_patterns_to_ninjatrader(patterns, dominant_color)
            elif pattern_mode == "both":
                send_patterns_to_ninjatrader(patterns, dominant_color)

        update_treeview_safe(tree, all_data)

    return all_data



def update_treeview_safe(tree, data):
    # Safely update the Treeview from another thread
    root.after(0, update_treeview, tree, data)

def detect_patterns(dominant_colors, deltas, delta_divergences, volatility_categories, market_bias, deltas15T, bid_numbers, ask_numbers, last_pattern_time):
    global pattern_mode
    patterns = []
    current_time = time.time()

    # Ensure the variables are lists
    dominant_colors = list(dominant_colors)
    delta_divergences = list(delta_divergences)
    volatility_categories = list(volatility_categories)
    market_bias = list(market_bias)
    deltas15T = list(deltas15T)

    imbalance = calculate_imbalance(bid_numbers, ask_numbers)

    # Check if at least 3 minutes have passed since the last pattern was detected
    if last_pattern_time is not None and current_time - last_pattern_time < 180:
        return patterns, last_pattern_time

    # Pattern 3: Buying, Buying, Buying, Buying with increasing delta (imbalance) values.
    if len(dominant_colors) >= 4 and len(deltas) >= 4:
        if (dominant_colors[-4] == "Buying" and dominant_colors[-3] == "Buying" and 
            dominant_colors[-2] == "Buying" and dominant_colors[-1] == "Buying" and 
            deltas[-4] < deltas[-3] < deltas[-2] < deltas[-1]):
            if pattern_mode in ("both", "buy"):
                patterns.append(3)
            last_pattern_time = current_time

    # Pattern 8: Selling, Selling, Selling, Selling with decreasing delta (imbalance) values.
    if len(dominant_colors) >= 4 and len(deltas) >= 4:
        if (dominant_colors[-4] == "Selling" and dominant_colors[-3] == "Selling" and 
            dominant_colors[-2] == "Selling" and dominant_colors[-1] == "Selling" and 
            deltas[-4] > deltas[-3] > deltas[-2] > deltas[-1]):
            if pattern_mode in ("both", "sell"):
                patterns.append(8)
            last_pattern_time = current_time

    # Pattern 4: Buying, Buying, Selling, Buying with delta (imbalance) >= 70.
    if len(dominant_colors) >= 4 and len(deltas) >= 4:
        if (dominant_colors[-4] == "Buying" and dominant_colors[-3] == "Buying" and 
            dominant_colors[-2] == "Selling" and dominant_colors[-1] == "Buying" and 
            imbalance >= 70):
            if pattern_mode in ("both", "buy"):
                patterns.append(4)
            last_pattern_time = current_time

    # Pattern 28: Buying, Selling, Buying, Selling with delta (imbalance) >= 60.
    if len(dominant_colors) >= 4 and len(deltas) >= 4:
        if (dominant_colors[-4] == "Buying" and dominant_colors[-3] == "Selling" and 
            dominant_colors[-2] == "Buying" and dominant_colors[-1] == "Selling" and 
            imbalance >= 60):
            if pattern_mode in ("both", "buy"):
                patterns.append(28)
            last_pattern_time = current_time

    # Pattern 34: Selling, Buying, Selling, Buying, Selling with delta (imbalance) >= 55.
    if len(dominant_colors) >= 5 and len(deltas) >= 5:
        if (dominant_colors[-5] == "Selling" and dominant_colors[-4] == "Buying" and 
            dominant_colors[-3] == "Selling" and dominant_colors[-2] == "Buying" and 
            dominant_colors[-1] == "Selling" and imbalance >= 80):
            if pattern_mode in ("both", "sell"):
                patterns.append(34)
            last_pattern_time = current_time

    # Pattern 37: Buying, Selling, Buying with delta (imbalance) >= 45.
    if len(dominant_colors) >= 3 and len(deltas) >= 3:
        if (dominant_colors[-3] == "Buying" and dominant_colors[-2] == "Selling" and 
            dominant_colors[-1] == "Buying" and imbalance >= 200):
            if pattern_mode in ("both", "buy"):
                patterns.append(37)
            last_pattern_time = current_time

    # Pattern 46: Buying, Selling, Buying, Buying with delta (imbalance) >= 65.
    if len(dominant_colors) >= 4 and len(deltas) >= 4:
        if (dominant_colors[-4] == "Buying" and dominant_colors[-3] == "Selling" and 
            dominant_colors[-2] == "Buying" and dominant_colors[-1] == "Buying" and 
            imbalance >= 100):
            if pattern_mode in ("both", "buy"):
                patterns.append(46)
            last_pattern_time = current_time
    
    # Pattern 54: Selling, Buying, Selling, Buying with delta (imbalance) >= 55.
    if len(dominant_colors) >= 4 and len(deltas) >= 4:
        if (dominant_colors[-4] == "Selling" and dominant_colors[-3] == "Buying" and 
            dominant_colors[-2] == "Selling" and dominant_colors[-1] == "Buying" and 
            imbalance >= 85):
            if pattern_mode in ("both", "sell"):
                patterns.append(54)
            last_pattern_time = current_time

    # Pattern 5: Buying, selling, buying, selling, divergence, with 4+ repeats
    for i in range(len(dominant_colors) - 6):
        for j in range(4, min(len(dominant_colors) - i, 7)):
            if all(dominant_colors[i + k] == ('Buying' if k % 2 == 0 else 'Selling') for k in range(j)) and \
               dominant_colors[i + j - 1] != dominant_colors[i + j]:
                if pattern_mode in ("both", "buy"):
                    patterns.append(5)
                last_pattern_time = current_time
                break

    return patterns, last_pattern_time

def calculate_imbalance(bid_numbers, ask_numbers):
    imbalance = 0
    for bid, ask in zip(bid_numbers, ask_numbers):
        if bid >= 2 * ask:
            imbalance += bid
    return imbalance



# Function to read connection code from the configuration file
def read_connection_code(config_file='config.json'):
    with open(config_file, 'r') as file:
        config = json.load(file)
    return config.get('connection_code')

# Connection code global variable
connection_code = read_connection_code()

# Function to update the connection label
def update_connection_label():
    connection_label.config(text=f"Connected to port: {connection_code}")

# Function to set the light color based on connection status
def set_connection_light(status):
    if status == "connected":
        connection_light.config(bg="green")
    elif status == "disconnected":
        connection_light.config(bg="red")

# Updated send_patterns_to_ninjatrader function to display port information and change light color
def send_patterns_to_ninjatrader(patterns, dominant_color):
    server_address = ('localhost', connection_code)  # Server address

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect(server_address)
            message = json.dumps({"Patterns": patterns, "DominantColor": dominant_color}).encode('utf-8')
            s.sendall(message)
            # Only log when patterns are sent successfully
            log_message = f"Sent patterns: {patterns} with dominant color: {dominant_color} to port: {connection_code}\n"
            log_to_gui(log_message)
            set_connection_light("connected")
    except Exception as e:
        # Only log when there's an error sending patterns
        
        set_connection_light("disconnected")

# Function to log messages to the Tkinter GUI
def log_to_gui(message):
    log_text.config(state=tk.NORMAL)
    log_text.insert(tk.END, message)
    log_text.config(state=tk.DISABLED)
    log_text.see(tk.END)

# Function to check connection status periodically
def check_connection_status():
    server_address = ('localhost', connection_code)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)  # Set a short timeout for quick checks
            s.connect(server_address)
            set_connection_light("connected")
    except:
        set_connection_light("disconnected")
    root.after(5000, check_connection_status)  # Check every 5 seconds

# Function to download data to a CSV file
def download_data():
    global all_data
    if not all_data:
        log_to_gui("No data available to download.\n")
        return

    file_path = f"trading_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    try:
        with open(file_path, mode='w', newline='') as file:
            writer = csv.writer(file)
            # Write headers
            writer.writerow(["Time", "Bid Numbers", "Ask Numbers", "Dominant Color", "Delta", "Patterns", "Delta Divergence", "Volatility Category", "Session"])
            # Write data rows
            for entry in all_data:
                writer.writerow([
                    entry['time'],
                    ','.join(map(str, entry['bid_numbers'])),
                    ','.join(map(str, entry['ask_numbers'])),
                    entry['dominant_color'],
                    entry['delta'],
                    ','.join(map(str, entry['patterns'])),
                    entry['delta_divergence'],
                    entry['volatility_category'],
                    entry['session']
                ])
        log_to_gui(f"Data downloaded successfully to {file_path}\n")
    except Exception as e:
        log_to_gui(f"Failed to download data: {e}\n")

# Tkinter GUI setup
root = tk.Tk()
root.title("Pattern Detection and Trading")

# Keep the window always on top
root.attributes("-topmost", True)

# Create and configure a connection label
connection_label = tk.Label(root, text=f"Connected to port: {connection_code}", font=("Arial", 10), fg="black")
connection_label.pack(pady=10)

# Add a label to represent the connection light
connection_light = tk.Label(root, text=" ", bg="red", width=5, height=2)
connection_light.pack(pady=10)

# Create a text widget for logging messages
log_text = tk.Text(root, state=tk.DISABLED, width=80, height=20)
log_text.pack(pady=10)

# Global recording flag
recording = False

# Function to toggle recording on and off
def toggle_recording():
    global recording
    recording = not recording
    if recording:
        recording_button.config(text="Stop Recording")
        threading.Thread(target=live_feed_processing, args=(tree,)).start()
    else:
        recording_button.config(text="Start Recording")

# Default pattern mode to both buying and selling patterns
pattern_mode = "both"

# Function to set the pattern mode (buy, sell, or both)
def set_pattern_mode(mode):
    global pattern_mode
    if mode == "buy":
        pattern_mode = "buy" if pattern_mode != "buy" else "both"
    elif mode == "sell":
        pattern_mode = "sell" if pattern_mode != "sell" else "both"
    elif mode == "both":
        pattern_mode = "both"
    log_to_gui(f"Pattern mode set to: {pattern_mode}\n")


# Tkinter GUI setup
root = tk.Tk()
root.title("Pattern Detection and Trading")
root.geometry("1000x700")  # Set window size
root.configure(bg="#222")  # Set background color to dark

# Keep the window always on top
root.attributes("-topmost", True)

# Header Label
header_label = tk.Label(
    root, 
    text="Pattern Detection Dashboard", 
    font=("Arial", 16, "bold"), 
    bg="#222", 
    fg="#fff"
)
header_label.pack(pady=10)

# Create and configure a connection label
connection_label = tk.Label(
    root, 
    text=f"Connected to port: {connection_code}", 
    font=("Arial", 10), 
    bg="#222", 
    fg="#fff"
)
connection_label.pack(pady=10)

# Add a label to represent the connection light
connection_light = tk.Label(
    root, 
    text=" ", 
    bg="red", 
    width=3, 
    height=1, 
    relief="flat", 
    bd=0
)
connection_light.pack(pady=10)

# Create a text widget for logging messages
log_text = tk.Text(
    root, 
    state=tk.DISABLED, 
    width=90, 
    height=15, 
    bg="#333", 
    fg="#fff", 
    font=("Arial", 10)
)
log_text.pack(pady=10)

# Create a frame for the control buttons
button_frame = tk.Frame(root, bg="#222")
button_frame.pack(pady=10)

# Create the Start Recording button
recording_button = tk.Button(
    button_frame, 
    text="Start Recording", 
    command=toggle_recording, 
    bg="#3a3", 
    fg="#fff", 
    font=("Arial", 10, "bold"), 
    relief="flat", 
    height=2, 
    width=20
)
recording_button.grid(row=0, column=0, padx=5)

# Create the Enable Buying Patterns button
buying_patterns_button = tk.Button(
    button_frame, 
    text="Enable Buying Patterns", 
    command=lambda: set_pattern_mode("buy"), 
    bg="#444", 
    fg="#0f0", 
    font=("Arial", 10, "bold"), 
    relief="flat", 
    height=2, 
    width=20
)
buying_patterns_button.grid(row=0, column=1, padx=5)

# Create the Enable Selling Patterns button
selling_patterns_button = tk.Button(
    button_frame, 
    text="Enable Selling Patterns", 
    command=lambda: set_pattern_mode("sell"), 
    bg="#444", 
    fg="#f00", 
    font=("Arial", 10, "bold"), 
    relief="flat", 
    height=2, 
    width=20
)
selling_patterns_button.grid(row=0, column=2, padx=5)

# Create the Enable Both Patterns button
both_patterns_button = tk.Button(
    button_frame, 
    text="Enable Both Patterns", 
    command=lambda: set_pattern_mode("both"), 
    bg="#444", 
    fg="#00f", 
    font=("Arial", 10, "bold"), 
    relief="flat", 
    height=2, 
    width=20
)
both_patterns_button.grid(row=0, column=3, padx=5)

# Create a frame for the TreeView and scrollbar
tree_frame = tk.Frame(root, bg="#222")
tree_frame.pack(fill="both", expand=True, pady=10)

# Add a vertical scrollbar to the TreeView frame
tree_scroll = tk.Scrollbar(tree_frame, orient="vertical", bg="#444")
tree_scroll.pack(side="right", fill="y")

# Create the TreeView widget
tree = ttk.Treeview(
    tree_frame, 
    columns=("Index", "Time", "Bid Numbers", "Ask Numbers", "Dominant Color", "Delta", "Patterns", "Delta Divergence", "Volatility Category", "Session"), 
    show="headings", 
    yscrollcommand=tree_scroll.set
)

# Set up TreeView headings
for col in ("Index", "Time", "Bid Numbers", "Ask Numbers", "Dominant Color", "Delta", "Patterns", "Delta Divergence", "Volatility Category", "Session"):
    tree.heading(col, text=col)
tree.pack(fill="both", expand=True)

# Configure the scrollbar to work with TreeView
tree_scroll.config(command=tree.yview)

# Add a Download Data button
download_button = tk.Button(
    root, 
    text="Download Data", 
    command=download_data, 
    bg="#ffcc00", 
    fg="#000", 
    font=("Arial", 10, "bold"), 
    relief="flat", 
    height=2, 
    width=20
)
download_button.pack(pady=10)

# Call update_connection_label to set the initial connection label text
update_connection_label()

# Start the connection status check loop
check_connection_status()

# Run the Tkinter main loop
root.mainloop()
