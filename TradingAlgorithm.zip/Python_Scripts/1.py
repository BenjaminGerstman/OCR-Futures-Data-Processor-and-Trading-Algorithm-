import pandas as pd
import os
from ast import literal_eval

# Load the dataset if it exists
csv_path = r'C:\Users\bgers\OneDrive\Delta Divigence ML ScreenRecording Project\output.csv5'
if os.path.exists(csv_path):
    df = pd.read_csv(csv_path)
else:
    df = pd.DataFrame(columns=['Column Number', 'Time', 'Bid Numbers', 'Ask Numbers', 'Time Difference', 'Dominant Color'])

# Ensure the necessary columns are initialized properly
df['Bid Numbers Eval'] = df['Bid Numbers'].apply(lambda x: literal_eval(x) if isinstance(x, str) else x)
df['Ask Numbers Eval'] = df['Ask Numbers'].apply(lambda x: literal_eval(x) if isinstance(x, str) else x)

# Calculate Total Bid and Ask Numbers and Delta
df['Total Bid Numbers'] = df['Bid Numbers Eval'].apply(sum)
df['Total Ask Numbers'] = df['Ask Numbers Eval'].apply(sum)
df['Delta'] = df['Total Bid Numbers'] - df['Total Ask Numbers']

# Determine Delta Divergence
def determine_divergence(delta, candle_type):
    if candle_type == 'Buying' and delta < 0:  # Selling delta on a buying candle
        return abs(delta)
    elif candle_type == 'Selling' and delta > 0:  # Buying delta on a selling candle
        return abs(delta)
    else:
        return 0

df['Delta Divergence'] = df.apply(lambda row: determine_divergence(row['Delta'], row['Dominant Color']), axis=1)

# Volatility and Session Calculation (unchanged)
def get_volatility_category(time_difference):
    if time_difference >= 901:
        return 'Very Low Volatility'
    elif 301 <= time_difference <= 900:
        return 'Low Volatility'
    elif 181 <= time_difference <= 300:
        return 'Moderate Volatility'
    elif 61 <= time_difference <= 180:
        return 'High Volatility'
    else:
        return 'Very High Volatility'

df['Volatility Category'] = df['Time Difference'].apply(get_volatility_category)

def get_session(time_str):
    try:
        hour = pd.to_datetime(time_str.strip("[]'"), format='%H:%M:%S', errors='coerce').time().hour
        if hour is None:
            return 'Invalid Time'
    except Exception as e:
        return 'Invalid Time'
    
    if 3 <= hour < 8:
        return '3am - 7:59am'
    elif 8 <= hour < 12:
        return '8am - 11:59am'
    elif 12 <= hour < 14:
        return '12pm - 1:59pm'
    elif 14 <= hour < 16:
        return '2pm - 3:59pm'
    elif 16 <= hour < 18:
        return '4pm - 5:59pm'
    elif 18 <= hour < 21:
        return '6pm - 8:59pm'
    else:
        return '9pm - 2:59am'

df['Session'] = df['Time'].apply(get_session)

# Function to determine market bias
def determine_market_bias(df, index):
    if index < 14:  # Not enough data to look back 15 bars
        return None
    recent_bars = df.iloc[index-14:index+1]['Dominant Color']
    buying_count = sum(1 for color in recent_bars if color == 'Buying')
    selling_count = sum(1 for color in recent_bars if color == 'Selling')
    total_count = len(recent_bars)
    
    buying_percentage = (buying_count / total_count) * 100
    selling_percentage = (selling_count / total_count) * 100
    
    if buying_percentage > 80:
        return 'Extreme Buying Bias'
    elif selling_percentage > 80:
        return 'Extreme Selling Bias'
    elif 70 <= buying_percentage < 80:
        return 'Bias 1 Buying'
    elif 70 <= selling_percentage < 80:
        return 'Bias 1 Selling'
    elif 40 <= buying_percentage <= 60 or 40 <= selling_percentage <= 60:
        return 'Neutral'
    else:
        return 'No Clear Bias'

df['Market Bias'] = df.index.to_series().apply(lambda i: determine_market_bias(df, i))

def analyze_patterns(df):
    patterns = {
        'Pattern 2': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 3': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 4': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 5': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 6': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 7': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 8': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 9': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 10': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 11': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 12': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 13': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 14': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 15': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 16': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 17': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 18': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 19': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}},
        'Pattern 20': {'Count': 0, 'Success': {i: {'Delta Divergence': [], 'Indexes': [], 'Count': 0} for i in range(1, 8)}, 'Failure': {i: 0 for i in range(1, 8)}}
      
    }

    def evaluate_trade(profit_target, pattern_name, start_index, direction):
        profit_count = 0
        loss_count = 0
        for j in range(start_index + 1, start_index + 8):  # Evaluate the next 7 bars
            if j >= len(df):
                break
            next_bar = df.iloc[j]
            if direction == 'Buying':
                if next_bar['Dominant Color'] == 'Buying':
                    profit_count += 1
                else:
                    loss_count += 1
            elif direction == 'Selling':
                if next_bar['Dominant Color'] == 'Selling':
                    profit_count += 1
                else:
                    loss_count += 1

            if profit_count >= profit_target:
                return 'Success'
            if loss_count >= profit_target:  # Stop loss reached
                return 'Failure'
        return 'Failure'  # If neither target was reached within the 7 bars, count as failure

    for i in range(len(df)):
        if i + 7 > len(df):
            continue
        window = df.iloc[i:i+7]

        for profit_target in range(1, 8):
            

            # Pattern 3: Buying, selling, buying, selling, divergence, with 4+ repeats
            for j in range(4, min(len(window), 7)):
                if all(window.iloc[k]['Dominant Color'] == ('Buying' if k % 2 == 0 else 'Selling') for k in range(j)) and \
                   window.iloc[j]['Dominant Color'] != window.iloc[j-1]['Dominant Color']:
                    patterns['Pattern 3']['Count'] += 1
                    dominant_color = window.iloc[0]['Dominant Color']
                    result = evaluate_trade(profit_target, 'Pattern 3', i + j, dominant_color)
                    if result == 'Success':
                        patterns['Pattern 3']['Success'][profit_target]['Delta Divergence'].append(window['Delta Divergence'].iloc[j])
                        patterns['Pattern 3']['Success'][profit_target]['Indexes'].append(i)
                        patterns['Pattern 3']['Success'][profit_target]['Count'] += 1
                    else:
                        patterns['Pattern 3']['Failure'][profit_target] += 1

          

            # Pattern 7: Inverse delta sequence
            if window.iloc[0]['Delta'] < 0 and \
               window.iloc[1]['Delta'] > 0 and \
               window.iloc[2]['Delta'] < 0 and \
               window.iloc[3]['Delta'] > 0:
                patterns['Pattern 7']['Count'] += 1
                dominant_color = window.iloc[1]['Dominant Color']
                result = evaluate_trade(profit_target, 'Pattern 7', i + 3, dominant_color)
                if result == 'Success':
                    patterns['Pattern 7']['Success'][profit_target]['Delta Divergence'].append(window['Delta Divergence'].iloc[3])
                    patterns['Pattern 7']['Success'][profit_target]['Indexes'].append(i)
                    patterns['Pattern 7']['Success'][profit_target]['Count'] += 1
                else:
                    patterns['Pattern 7']['Failure'][profit_target] += 1

        
                            # Pattern 9: Sudden change
            if window.iloc[0]['Delta'] > 0 and \
               window.iloc[1]['Delta'] < 0:
                patterns['Pattern 9']['Count'] += 1
                dominant_color = window.iloc[1]['Dominant Color']
                result = evaluate_trade(profit_target, 'Pattern 9', i + 1, dominant_color)
                if result == 'Success':
                    patterns['Pattern 9']['Success'][profit_target]['Delta Divergence'].append(window['Delta Divergence'].iloc[1])
                    patterns['Pattern 9']['Success'][profit_target]['Indexes'].append(i)
                    patterns['Pattern 9']['Success'][profit_target]['Count'] += 1
                else:
                    patterns['Pattern 9']['Failure'][profit_target] += 1

            

            

           
    return patterns

# Analyze the patterns in the dataframe
found_patterns = analyze_patterns(df)

# Correctly accessing each pattern's count
for pattern_name, data in found_patterns.items():
    total_count = data['Count']
    for profit_target in range(1, 8):
        success_count = data['Success'][profit_target]['Count']
        failure_count = data['Failure'][profit_target]
        print(f"{pattern_name} (Profit Target {profit_target} bars): Total Count - {total_count}, Success Count - {success_count}, Failure Count - {failure_count}")

# Printing average delta divergence for each pattern
print("\nAverage Delta Divergence for Each Pattern (Success/Failure):")
for pattern, levels in found_patterns.items():
    for profit_target in range(1, 8):
        total_count = levels['Success'][profit_target]['Count']
        if total_count > 0:
            average_divergence = sum(levels['Success'][profit_target]['Delta Divergence']) / total_count
        else:
            average_divergence = 0
        print(f"{pattern} (Profit Target {profit_target} bars): Success - Average Delta Divergence: {average_divergence:.2f}")

# Printing success rates for each pattern
print("\nSuccess Rate for Each Pattern:")
for pattern, levels in found_patterns.items():
    for profit_target in range(1, 8):
        total_success = levels['Success'][profit_target]['Count']
        total_count = levels['Count']
        success_rate = (total_success / total_count) * 100 if total_count > 0 else 0
        print(f"{pattern} (Profit Target {profit_target} bars): Success Rate - {success_rate:.2f}%")

    

    
