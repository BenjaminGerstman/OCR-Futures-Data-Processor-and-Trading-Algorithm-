#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public class OCRPLUS : Strategy
    {
        private double internalProfitGoal;
        private double internalLossThreshold;
        private bool internalIsLiveTrading;
        private string internalPatternMode;
        private Thread internalListenerThread;
        private bool internalRunning;
        private bool internalIsTradeOpen = false;

        [NinjaScriptProperty]
        [Display(Name = "Profit Goal", Order = 1, GroupName = "Parameters")]
        public double ConfiguredProfitGoal { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Loss Threshold", Order = 2, GroupName = "Parameters")]
        public double ConfiguredLossThreshold { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Connection Code", Order = 3, GroupName = "Parameters")]
        public int ConfiguredConnectionCode { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "OCRPLUS";
                Calculate = Calculate.OnEachTick;
                IsInstantiatedOnEachOptimizationIteration = false;
                internalProfitGoal = 1000; // Default profit goal
                internalLossThreshold = 500; // Default loss threshold
                internalPatternMode = "both"; // Default to both buying and selling patterns
                ConfiguredConnectionCode = 65432; // Default connection code
            }
            else if (State == State.Configure)
            {
                AddDataSeries(Data.BarsPeriodType.Tick, 1); // Configure your data series
            }
            else if (State == State.DataLoaded)
            {
                StartInternalListener();
            }
            else if (State == State.Terminated)
            {
                StopInternalListener();
            }
        }

        protected override void OnBarUpdate()
        {
            if (BarsInProgress != 0)
                return;

            double currentProfit = SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit;

            if (currentProfit >= internalProfitGoal)
            {
                Print("Profit goal reached. Stopping strategy.");
                DisableStrategy();
            }
            else if (currentProfit <= -internalLossThreshold)
            {
                Print("Loss threshold reached. Stopping strategy.");
                DisableStrategy();
            }

            // Check if trade is closed
            if (internalIsTradeOpen && Position.MarketPosition == MarketPosition.Flat)
            {
                internalIsTradeOpen = false;
            }
        }

        public void HandlePatternReceived(int[] patterns, string dominantColor)
        {
            if (internalIsTradeOpen)
            {
                Print("A trade is already open. Waiting for it to close before taking new trades.");
                return;
            }

            foreach (int pattern in patterns)
            {
                if (dominantColor == "Buying" && (internalPatternMode == "buy" || internalPatternMode == "both"))
                {
                    EnterLong("Pattern" + pattern);
                    SetProfitTarget(CalculationMode.Ticks, ConfiguredProfitGoal);
                    SetStopLoss(CalculationMode.Ticks, ConfiguredLossThreshold);
                    internalIsTradeOpen = true;
                }
                else if (dominantColor == "Selling" && (internalPatternMode == "sell" || internalPatternMode == "both"))
                {
                    EnterShort("Pattern" + pattern);
                    SetProfitTarget(CalculationMode.Ticks, ConfiguredProfitGoal);
                    SetStopLoss(CalculationMode.Ticks, ConfiguredLossThreshold);
                    internalIsTradeOpen = true;
                }
            }
        }

        private void DisableStrategy()
        {
            Print("Disabling strategy...");
            // Add any other cleanup code here
        }

        private void StartInternalListener()
        {
            internalRunning = true;
            internalListenerThread = new Thread(() =>
            {
                TcpListener listener = new TcpListener(System.Net.IPAddress.Any, ConfiguredConnectionCode);
                listener.Start();
                Print($"Listening for pattern signals on port {ConfiguredConnectionCode}...");

                while (internalRunning)
                {
                    try
                    {
                        using (TcpClient client = listener.AcceptTcpClient())
                        using (NetworkStream stream = client.GetStream())
                        {
                            byte[] buffer = new byte[1024];
                            int bytesRead = stream.Read(buffer, 0, buffer.Length);
                            if (bytesRead > 0)
                            {
                                string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                                dynamic data = Newtonsoft.Json.JsonConvert.DeserializeObject(message);
                                int[] patterns = data.Patterns.ToObject<int[]>();
                                string dominantColor = data.DominantColor.ToString();
                                HandlePatternReceived(patterns, dominantColor);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Print("Error receiving pattern signal: " + ex.Message);
                    }
                }

                listener.Stop();
                Print("Stopped listening for pattern signals.");
            });

            internalListenerThread.IsBackground = true;
            internalListenerThread.Start();
        }

        private void StopInternalListener()
        {
            internalRunning = false;
            internalListenerThread?.Join();
        }
    }
}